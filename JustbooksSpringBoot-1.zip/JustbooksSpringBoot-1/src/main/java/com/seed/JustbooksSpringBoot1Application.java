package com.seed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JustbooksSpringBoot1Application {

	public static void main(String[] args) {
		SpringApplication.run(JustbooksSpringBoot1Application.class, args);
		System.out.println("started");
	}

}
