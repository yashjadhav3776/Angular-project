package com.seed.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.seed.db.FeedBackRepo;
import com.seed.db.UserRepository;
import com.seed.model.FeedBack;


@CrossOrigin("http://localhost:4200")
@RestController
public class FeedBackController {
	
	@Autowired
	FeedBackRepo feedBackRepo;
	
	@PostMapping("/addfeedback")
	public void addFeedBack(@RequestBody FeedBack user) {
		System.out.println("Controller ....addfeedback...");
		feedBackRepo.save(user);
	}

}