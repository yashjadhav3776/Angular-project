package com.seed.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.seed.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {
}