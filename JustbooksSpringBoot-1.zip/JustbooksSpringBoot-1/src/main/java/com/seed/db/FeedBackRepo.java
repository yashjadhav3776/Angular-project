package com.seed.db;



import org.springframework.data.jpa.repository.JpaRepository;

import com.seed.model.FeedBack;


public interface FeedBackRepo extends JpaRepository<FeedBack, String>{

	static void savefeedback(FeedBack user) {
		// TODO Auto-generated method stub
		
	}
	
	
}