package com.seed.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name="feedback")
public class FeedBack {
	@Id
	@Column(name="email",length=50)
	private String email;
	
	@Column(name="name",length=50)
	private String name;
	
	@Column(name="feedBack",length=100)
	private String feedBack;
	
}
